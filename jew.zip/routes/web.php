<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\RoleController;
use App\Http\Controllers\Admin\PermissionController;
use App\Http\Controllers\Admin\TranslateController;


Route::get('/', function () {
    return view('welcome');
});

Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::get('/register', [AuthController::class, 'showRegisterForm'])->name('register');
Route::post('/register', [AuthController::class, 'register']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

Route::group(['middleware' => ['dashboard']], function () {
    Route::get('/admin', [AdminController::class, 'index'])->name('admin.dashboard');

    Route::prefix('admin')->group(function () {



        Route::get('/permissions', [PermissionController::class, 'index'])->middleware('can:permission_view')->name('permissions.index');
        Route::get('/permissions/create', [PermissionController::class, 'create'])->middleware('can:permission_create')->name('permissions.create');
        Route::post('/permissions/create', [PermissionController::class, 'store'])->middleware('can:permission_create')->name('permissions.store');
        Route::get('/permissions/{permission}/edit', [PermissionController::class, 'edit'])->middleware('can:permission_edit')->name('permissions.edit');
        Route::post('/permissions/{permission}/edit', [PermissionController::class, 'update'])->middleware('can:permission_edit')->name('permissions.update');


        Route::get('/roles', [RoleController::class, 'index'])->middleware('can:role_view')->name('roles.index');
        Route::get('/roles/create', [RoleController::class, 'create'])->middleware('can:role_create')->name('roles.create');
        Route::post('/roles/create', [RoleController::class, 'store'])->middleware('can:role_create')->name('roles.store');
        Route::get('/roles/{role}/edit', [RoleController::class, 'edit'])->middleware('can:role_edit')->name('roles.edit');
        Route::post('/roles/{role}/edit', [RoleController::class, 'update'])->middleware('can:role_edit')->name('roles.update');

        Route::get('/translate', [TranslateController::class, 'index'])->name('translate.index');
        Route::post('/translate',  [TranslateController::class, 'update'])->name('translate.update');
        Route::post('/translate/create',  [TranslateController::class, 'create_files'])->name('translate.create');


    });


});
